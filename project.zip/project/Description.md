
## Project description

- Two static pages
- Header with links
- ejs templating
- assets(css, images)
- async route handlers
- 404 page

## Start project

- Run *npm install*
- Run *npm run start-dev*
- Visit [http://localhost:5000](http://localhost:5000) with browser